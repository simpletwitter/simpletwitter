This package can be used to make your own twitter bot with less code

import the package using pip install

`usage`:

```
from twitterbot_abipravi import Twitterbot
bot = Twitterbot(email, password, no_of_tweets, username)
bot.login()
bot.like_tweet(hashtags) #like the twitte
bot.Unlike_liked_tweets(5) #unlike the liked tweet
```
